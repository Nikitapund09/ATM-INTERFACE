package atm.com;

public class Atm {
	private double balance;
	private double depositeAccount;
	private double widrawAccount;
	
	

}
