package atm.com;

public interface AtmoperationInterf {
	public void viewBalance();
	public void  withdrawAmount(double withdrawAmount);
	public void  depositeAmount(double depositeAmount);
	public void  viewMiniStatement();
//	public void transactionHistory
}
